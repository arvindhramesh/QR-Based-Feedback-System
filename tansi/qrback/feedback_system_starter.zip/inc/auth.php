<?php
// Auth check and session start
?>