<?php
$conn = oci_connect('username', 'password', 'localhost/XE');
if (!$conn) {
    $e = oci_error();
    die("Connection failed: " . $e['message']);
}
?>