<?php
// Registration form and logic
?>