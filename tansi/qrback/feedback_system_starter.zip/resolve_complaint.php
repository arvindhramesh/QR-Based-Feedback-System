<?php
// Staff/Admin resolves complaints
?>